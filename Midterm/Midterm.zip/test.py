//Feature selection
X = df.drop(columns=['sub_category','category','deadline','launched','backers','country','pledged','goal','target']).values
Y = df['target'].values

//Model selection: 
from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, random_state=723, test_size=0.15, stratify=Y)

print(f'Training set: {X_train.shape}, {Y_train.shape}')
print(f'Test set: {X_test.shape}, {Y_test.shape}')

X_valid, X_test, y_valid, y_test = train_test_split(X_test, y_test,random_state=42,test_size=0.50)
print(f'Validation set: {X_valid.shape}, {y_valid.shape}')

//Heatmap
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns

fi, axis = plt.subplots(figsize=(10, 8))
corr = data_df.corr()
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(200,10,as_cmap=True), 
           square=True, ax=axis)

//disturbution
import seaborn as sns
%matplotlib inline
import matplotlib.pyplot as plt
fi= plt.figure(figsize=(14,5))

axis=fi.add_subplot(121)
sns.distplot(data_df['goal'],color='b',ax=axis)
axis.set_title('The distribution of goal')



from datetime import datetime
time1 = datetime(2012, 3, 5, 23, 8, 15) 
time2 = datetime.now() 

print(time2-time1)


df.launched = pd.to_datetime(df.launched)
df.deadline = pd.to_datetime(df.deadline)
differenceDate = df.launched - df.deadline
print(differenceDate)

plt.subplots(figsize=(12, 8))
sns.set(font_scale=1.2)
ax = sns.scatterplot(x="target", y="backers", data=df)

g = sns.jointplot(x="target_code", y="pledged", data = df,kind="kde", color="g")
g.plot_joint(plt.scatter, c="w", s=30, linewidth=1, marker="+")
g.ax_joint.collections[0].set_alpha(0)
g.set_axis_labels("$target_code$", "$backers$")
ax.set_title('Distribution of Target and backers')